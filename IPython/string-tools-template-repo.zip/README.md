# string-tools (Template)

A GitHub template repository for a tiny Python package with:
- `src/` layout
- tests via `pytest`
- CI via GitHub Actions
- **release-please** automated releases
- issue templates & PR template
- dependabot for automated dependency updates

> Generated on 2025-10-17. Customize names and metadata before publishing.
