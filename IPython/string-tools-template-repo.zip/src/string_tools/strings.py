import re

_BOUNDARY = re.compile(r"(?<!^)([A-Z])")

def camel_to_snake(s: str) -> str:
    if not isinstance(s, str):
        raise TypeError("s must be a str")
    return _BOUNDARY.sub(r"_\1", s).lower()

def is_palindrome(s: str) -> bool:
    if not isinstance(s, str):
        raise TypeError("s must be a str")
    t = "".join(ch.lower() for ch in s if ch.isalnum())
    return t == t[::-1]
