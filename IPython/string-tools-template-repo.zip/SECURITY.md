# Security Policy

If you discover a security issue, please email security@example.com. Do not open a public issue.
We aim to triage within 72 hours.
