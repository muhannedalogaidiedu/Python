# Contributing

Thanks for your interest! Please:
1. Fork the repo and create a feature branch.
2. Run `python -m venv .venv && source .venv/bin/activate` (or Windows equivalent).
3. `python -m pip install -U pip build && python -m pip install -e .[dev]`
4. Run `pytest -q` before pushing.
5. Open a PR and fill out the PR template.
