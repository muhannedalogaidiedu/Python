import pytest
from string_tools import camel_to_snake, is_palindrome

def test_camel_to_snake_basic():
    assert camel_to_snake("CamelCase") == "camel_case"

def test_palindrome_true():
    assert is_palindrome("A man, a plan, a canal: Panama")

def test_palindrome_false():
    assert not is_palindrome("hello")
