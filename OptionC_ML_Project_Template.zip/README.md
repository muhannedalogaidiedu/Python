# ML Project Template

A structured machine learning / data science project template.

## Structure

- `data/` — raw and processed data
- `notebooks/` — Jupyter notebooks
- `src/ml_project/` — reusable Python modules
- `tests/` — tests for core logic

## Installation

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

## Usage

1. Place raw data in `data/raw/`.
2. Use notebooks in `notebooks/` for exploration.
3. Move stable logic into `src/ml_project/`.
4. Run training via scripts or CLI commands.

## Testing

```bash
pytest
```
