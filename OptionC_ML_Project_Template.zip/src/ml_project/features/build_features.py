import pandas as pd

def add_example_feature(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["example_feature"] = 1
    return df
