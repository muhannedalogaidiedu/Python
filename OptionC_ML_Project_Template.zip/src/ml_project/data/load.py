from pathlib import Path
import pandas as pd

def load_raw_data(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    return pd.read_csv(path)
