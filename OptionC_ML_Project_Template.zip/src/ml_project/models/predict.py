from pathlib import Path
import joblib

def load_model(model_path: str | Path):
    return joblib.load(Path(model_path))
