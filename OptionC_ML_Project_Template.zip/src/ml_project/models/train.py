from pathlib import Path
import joblib
from sklearn.ensemble import RandomForestClassifier

def train_model(X, y, model_path: str | Path) -> None:
    model = RandomForestClassifier()
    model.fit(X, y)
    model_path = Path(model_path)
    model_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, model_path)
