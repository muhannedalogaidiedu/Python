# string-tools

A tiny example library with two helpers:
- `camel_to_snake(s)` — convert CamelCase to snake_case
- `is_palindrome(s)` — check palindromes ignoring punctuation and case

## Quickstart

```bash
# (Optional) create & activate a venv
python -m venv .venv
# Windows: .venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate

python -m pip install --upgrade pip build

# Install in editable mode (dev)
python -m pip install -e .[dev]

# Run tests
pytest -q

# Build distributions (sdist + wheel)
python -m build

# (Optional) Upload to TestPyPI
python -m pip install twine
twine upload --repository testpypi dist/*
```

## Usage

```python
from string_tools import camel_to_snake, is_palindrome

print(camel_to_snake("CamelCaseToSnake"))  # camel_case_to_snake
print(is_palindrome("A man, a plan, a canal: Panama"))  # True
```

## Project Layout

```
sample-string-tools/
├─ pyproject.toml
├─ README.md
├─ LICENSE
├─ src/
│  └─ string_tools/
│     ├─ __init__.py
│     └─ strings.py
└─ tests/
   └─ test_strings.py
```

---

Built on 2025-10-17.
