import re
from typing import Final

# Convert CamelCase to snake_case
_CAMEL_BOUNDARY: Final = re.compile(r"(?<!^)([A-Z])")

def camel_to_snake(s: str) -> str:
    """Convert CamelCase named identifiers to snake_case.
    Examples:
        CamelCase  -> camel_case
        HTTPServer -> http_server
    """
    if not isinstance(s, str):
        raise TypeError("s must be a str")
    return _CAMEL_BOUNDARY.sub(r"_\1", s).lower()

def is_palindrome(s: str) -> bool:
    """Return True if s reads the same forward/backward, ignoring case and punctuation."""
    if not isinstance(s, str):
        raise TypeError("s must be a str")
    t = ''.join(ch.lower() for ch in s if ch.isalnum())
    return t == t[::-1]
