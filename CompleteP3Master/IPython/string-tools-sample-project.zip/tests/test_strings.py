import pytest
from string_tools import camel_to_snake, is_palindrome

@pytest.mark.parametrize("inp, out", [
    ("CamelCase", "camel_case"),
    ("HTTPServer", "http_server"),
    ("Simple", "simple"),
    ("", ""),
])
def test_camel_to_snake(inp, out):
    assert camel_to_snake(inp) == out

@pytest.mark.parametrize("bad", [None, 123, 3.14, []])
def test_camel_to_snake_type_errors(bad):
    with pytest.raises(TypeError):
        camel_to_snake(bad)  # type: ignore

@pytest.mark.parametrize("text, expected", [
    ("A man, a plan, a canal: Panama", True),
    ("racecar", True),
    ("hello", False),
    ("", True),
])
def test_is_palindrome(text, expected):
    assert is_palindrome(text) == expected

@pytest.mark.parametrize("bad", [None, 123, 3.14, {}])
def test_is_palindrome_type_errors(bad):
    with pytest.raises(TypeError):
        is_palindrome(bad)  # type: ignore
