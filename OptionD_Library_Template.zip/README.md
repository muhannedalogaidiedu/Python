# my-library

A small example Python library.

## Installation

```bash
pip install my-library
```

## Usage

```python
from my_library import add, subtract

print(add(1, 2))
print(subtract(5, 3))
```

## Development

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
pytest
```

## License

MIT
