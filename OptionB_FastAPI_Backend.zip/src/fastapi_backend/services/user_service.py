from typing import List, Dict

def get_users() -> List[Dict[str, str]]:
    return [
        {"id": "1", "name": "Alice"},
        {"id": "2", "name": "Bob"},
    ]
