# FastAPI Backend Template

A clean, modular FastAPI backend using the `src/` layout.

## Features

- Health check endpoint
- User routes and service layer
- Ready for expansion (DB, auth, etc.)
- pytest-based tests

## Installation

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

## Run the Server

```bash
uvicorn fastapi_backend.main:app --reload
```

Open `http://127.0.0.1:8000/docs` for the API docs.

## Testing

```bash
pytest
```
