from .core.utils import say_hello

def main() -> None:
    name = "World"
    message = say_hello(name)
    print(message)

if __name__ == "__main__":
    main()
