from ..core.utils import say_hello

def greet_user(username: str) -> str:
    return say_hello(username)
