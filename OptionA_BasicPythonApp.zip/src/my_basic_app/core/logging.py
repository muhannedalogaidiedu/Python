import logging

logger = logging.getLogger("my_basic_app")

def setup_logging(level: int = logging.INFO) -> None:
    logging.basicConfig(level=level)
    logger.info("Logging is configured.")
