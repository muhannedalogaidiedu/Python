# my_basic_app

A basic Python application using the modern `src/` layout.

## Features

- Clean project structure
- Simple `main.py` entry point
- Example utility module
- Basic pytest test

## Installation

```bash
python -m venv .venv
source .venv/bin/activate  # or Windows equivalent
pip install -e ".[dev]"
```

## Usage

```bash
python -m my_basic_app.main
```

## Testing

```bash
pytest
```

## License

MIT (or choose your own)
