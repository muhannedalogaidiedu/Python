from my_basic_app.core.utils import say_hello

def test_say_hello():
    assert say_hello("World") == "Hello, World!"
